# 📈 Stock-Finance

A simple Python CLI tool to fetch and display real-time stock prices using the `yfinance` library.

---

## 🚀 How It Works

This script:
- Asks the user for a stock symbol (e.g., AAPL, MSFT)
- Uses `yfinance` to get the latest market data
- Displays the **closing price** and **date**

---

## ▶️ Example

```bash
Enter stock symbol (e.g., AAPL, MSFT): AAPL  
AAPL closing price on 2025-07-25: $192.85
```

---

## ⚙️ Setup

1. Install yfinance:
```bash
pip install yfinance
```

2. Run the script:
```bash
python main.py
```

---

## 🛠 Built With

- Python 3.x
- yfinance

---

## 📄 License

[MIT](LICENSE)
